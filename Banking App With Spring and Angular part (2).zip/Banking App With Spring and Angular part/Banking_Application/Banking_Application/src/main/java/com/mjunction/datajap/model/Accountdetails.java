package com.mjunction.datajap.model;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.UniqueConstraint;



@Entity
public class Accountdetails {
              
              @Id
              @Column(name="customerid")
              private int CustomerId;
              @Column(name="name")
              private String Name ;
              @Column(name="dob")
              private Date Dob ;
              @Column(name="accnumber")
               private BigInteger Accnumber; 
              @Column(name="phone")
               private BigInteger Phone;
              @Column(name="email")
              private String Email;
              @Column(name="balance")
              private double Balance;
			public int getCustomerId() {
				return CustomerId;
			}
			public void setCustomerId(int customerId) {
				CustomerId = customerId;
			}
			public String getName() {
				return Name;
			}
			public void setName(String name) {
				Name = name;
			}
			public Date getDob() {
				return Dob;
			}
			public void setDob(Date dob) {
				Dob = dob;
			}
			public BigInteger getAccnumber() {
				return Accnumber;
			}
			public void setAccnumber(BigInteger accnumber) {
				Accnumber = accnumber;
			}
			public BigInteger getPhone() {
				return Phone;
			}
			public void setPhone(BigInteger phone) {
				Phone = phone;
			}
			public String getEmail() {
				return Email;
			}
			public void setEmail(String email) {
				Email = email;
			}
			public double getBalance() {
				return Balance;
			}
			public void setBalance(double balance) {
				Balance = balance;
			}
			public Accountdetails(int customerId, String name, Date dob, BigInteger accnumber, BigInteger phone,
					String email, double balance) {
				super();
				CustomerId = customerId;
				Name = name;
				Dob = dob;
				Accnumber = accnumber;
				Phone = phone;
				Email = email;
				Balance = balance;
			}
			@Override
			public String toString() {
				return "Accountdetails [CustomerId=" + CustomerId + ", Name=" + Name + ", Dob=" + Dob + ", Accnumber="
						+ Accnumber + ", Phone=" + Phone + ", Email=" + Email + ", Balance=" + Balance + "]";
			}
			public Accountdetails() {
				super();
				// TODO Auto-generated constructor stub
			}
              
              
}
