package com.mjunction.datajap.repo;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.mjunction.datajap.model.Userdetails;

public interface UserRepo extends JpaRepository<Userdetails, Integer> {

	Userdetails findByCId(int cId);
	@Query("from Userdetails where phone = :ph")
	public Userdetails findByPh(@Param("ph") BigInteger phone);
	void deleteByCId(int id);
	
}
