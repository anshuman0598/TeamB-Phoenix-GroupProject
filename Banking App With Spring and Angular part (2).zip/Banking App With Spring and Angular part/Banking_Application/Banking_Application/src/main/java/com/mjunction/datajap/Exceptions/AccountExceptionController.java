package com.mjunction.datajap.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class AccountExceptionController 
{
	@ExceptionHandler(value= AccountNotFoundException.class)
	public ResponseEntity<Object> exceptionNotFound(AccountNotFoundException ex)
	{
		return new ResponseEntity<>("Account Record Not Found",HttpStatus.NOT_FOUND);
	}

}
