package com.mjunction.datajap.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admindetails {
				@Id
			  @Column(name="Adminid")
			   private int Adminid;
			  @Column(name="Aname")
              private String Aname;
           
              @Column(name="Phone")
              private BigInteger Phone;
              @Column(name="Email")
              private String Email;
              @Column(name="Password")
              private String Password;
			public String getAname() {
				return Aname;
			}
			public void setAname(String aname) {
				Aname = aname;
			}
			public BigInteger getPhone() {
				return Phone;
			}
			public void setPhone(BigInteger phone) {
				Phone = phone;
			}
			public String getEmail() {
				return Email;
			}
			public void setEmail(String email) {
				Email = email;
			}
			public String getPassword() {
				return Password;
			}
			public void setPassword(String password) {
				Password = password;
			}
			public Admindetails(int adminid, String aname, BigInteger phone, String email, String password) {
				super();
				Adminid = adminid;
				Aname = aname;
				Phone = phone;
				Email = email;
				Password = password;
			}
			public int getAdminid() {
				return Adminid;
			}
			public void setAdminid(int adminid) {
				Adminid = adminid;
			}
			@Override
			public String toString() {
				return "Admindetails [Adminid=" + Adminid + ", Aname=" + Aname + ", Phone=" + Phone + ", Email=" + Email
						+ ", Password=" + Password + "]";
			}
			
			public Admindetails() {
				super();
				// TODO Auto-generated constructor stub
			}
            
              
              
              
}
