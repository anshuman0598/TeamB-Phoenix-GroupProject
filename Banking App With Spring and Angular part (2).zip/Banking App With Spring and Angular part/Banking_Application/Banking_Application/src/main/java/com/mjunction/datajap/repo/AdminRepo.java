package com.mjunction.datajap.repo;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mjunction.datajap.model.Admindetails;

public interface AdminRepo extends JpaRepository<Admindetails ,Integer>{

	@Query("from Admindetails where phone = :ph")
	Admindetails findByPhone(@Param("ph") BigInteger phone);
    

}

