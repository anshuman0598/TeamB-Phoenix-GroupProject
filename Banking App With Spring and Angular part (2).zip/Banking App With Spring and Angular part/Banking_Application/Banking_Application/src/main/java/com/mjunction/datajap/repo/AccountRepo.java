package com.mjunction.datajap.repo;
import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mjunction.datajap.model.Accountdetails;
public interface AccountRepo extends JpaRepository<Accountdetails ,Integer>
{
	@Query("from Accountdetails where accnumber=:accnum")
	public Accountdetails getByAccnum(@Param("accnum") BigInteger accnum);
	
}
