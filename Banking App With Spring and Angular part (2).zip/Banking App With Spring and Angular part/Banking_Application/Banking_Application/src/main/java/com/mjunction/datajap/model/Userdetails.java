package com.mjunction.datajap.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Userdetails {
	@Id
	@Column(name="Userid")
	private int UserId;
	@Column(name="Phone")
	private BigInteger Phone;
	@Column(name="email")
	private String Email;
	@Column(name="Password")
	private String Password;
	@Column(name="CId")
	private int CId;
	@Column(name="Mpin")
	private int Mpin;
	@Override
	public String toString() {
		return "Userdetails [UserId=" + UserId + ", Phone=" + Phone + ", Email=" + Email + ", Password=" + Password
				+ ", CId=" + CId + ", Mpin=" + Mpin + "]";
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public BigInteger getPhone() {
		return Phone;
	}
	public void setPhone(BigInteger phone) {
		Phone = phone;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public int getCId() {
		return CId;
	}
	public void setCId(int cId) {
		CId = cId;
	}
	public int getMpin() {
		return Mpin;
	}
	public void setMpin(int mpin) {
		Mpin = mpin;
	}
	public Userdetails(int userId, BigInteger phone, String email, String password, int cId, int mpin) {
		super();
		UserId = userId;
		Phone = phone;
		Email = email;
		Password = password;
		CId = cId;
		Mpin = mpin;
	}
	public Userdetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}