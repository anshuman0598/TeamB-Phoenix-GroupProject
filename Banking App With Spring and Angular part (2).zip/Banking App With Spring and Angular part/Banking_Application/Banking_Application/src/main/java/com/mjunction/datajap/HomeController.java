package com.mjunction.datajap;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mjunction.datajap.Exceptions.AccountNotFoundException;
import com.mjunction.datajap.model.Accountdetails;
import com.mjunction.datajap.model.Admindetails;
import com.mjunction.datajap.model.Userdetails;
import com.mjunction.datajap.repo.AccountRepo;
import com.mjunction.datajap.repo.AdminRepo;
import com.mjunction.datajap.repo.UserRepo;
@CrossOrigin(value= "*")
@RestController

public class HomeController {
	@Autowired
	AccountRepo accRepo;

	@Autowired
	AdminRepo adRepo;

	@Autowired
	UserRepo usRepo;
	//Admin Functions
	
	@GetMapping("/admin/BankUsers")
	public List<Accountdetails> getAllUsers() {
		return accRepo.findAll();
	}
	@GetMapping("/admin/admins")
	public List<Admindetails> getAllAdmin()
	{
		return adRepo.findAll();
		}
	@GetMapping("/admin/{phone}/{password}")
	public ResponseEntity<?> getAdmin(@PathVariable("phone") BigInteger phone, @PathVariable String password)
	{
		System.out.println(phone+""+password);
		Admindetails detail = adRepo.findByPhone(phone);
		if(detail.getPassword().equals(password))
			return ResponseEntity.ok(detail);
		return (ResponseEntity<?>) ResponseEntity.internalServerError();
	}

	@GetMapping(path = "/admin/useraccountdetail/{Id}")
	public ResponseEntity<Accountdetails> getUserDetail(@PathVariable("Id") int userid) {
		Accountdetails udetails = accRepo.findById(userid).orElseThrow(() -> new AccountNotFoundException());
		return ResponseEntity.ok(udetails);
	}

	@PostMapping(path = "/admin/bankusers/create")
	public void insertAccount(@RequestBody Accountdetails details) {
		BigInteger a = BigInteger.valueOf((long) Math.floor(Math.random() * 1000.00));
		// System.out.print(a);
		details.setAccnumber(a.add(details.getPhone()));

		accRepo.save(details);
	}

	@PutMapping(path = "/admin/bankusers/update/{id}")
	public void updateAccount(@PathVariable("id") int id, @RequestBody Accountdetails details) 
	{
		Accountdetails detail= accRepo.findById(id).orElseThrow(() -> new AccountNotFoundException());
		detail.setDob(details.getDob());
		detail.setName(details.getName());
		detail.setEmail(details.getEmail());
		detail.setPhone(details.getPhone());
		accRepo.save(detail);
	}
	@GetMapping(path = "/admin/useraccountdetails/")
	public List<Accountdetails> getUserDetails() {
	    return accRepo.findAll();
		
	}
	@DeleteMapping(path ="/admin/userdetail/delete/{id}")
	public void deleteAccount(@PathVariable int id)
	{
		accRepo.deleteById(id);
		usRepo.deleteByCId(id);
	}
	//User Services
	
	// @SuppressWarnings("deprecation")
	@PostMapping("/user/createuser")
	public ResponseEntity<Userdetails> createAccount(@RequestBody Userdetails user)
	{
		//User us=user;
		
		Accountdetails details = accRepo.findById(user.getCId()).orElseThrow(() -> new AccountNotFoundException());
		usRepo.save(user);
		return ResponseEntity.ok(user);
	}

	@GetMapping("user/users")
	public List<Userdetails> getUsers()
	{
		return usRepo.findAll();
	}
	
	@GetMapping(path = "/user/BankDetails/{id}")
	public ResponseEntity<Accountdetails> getAccountdetail(@PathVariable("id") int customerid) {
		Accountdetails details = accRepo.findById(customerid).orElseThrow(() -> new AccountNotFoundException());
		return ResponseEntity.ok(details);

	}
	
	@GetMapping(path = "/user/AccountDetails/{Id}")
	public ResponseEntity<Userdetails> getUserDetails(@PathVariable("Id") int userid) {
		Userdetails udetails = usRepo.findById(userid).orElseThrow(() -> new AccountNotFoundException());
		return ResponseEntity.ok(udetails);
	}
	
	
	  @GetMapping("/user/find/{CId}") 
	  public Userdetails getUserExist(@PathVariable("CId")int CId) 
	  {
		  Userdetails usdetail=usRepo.findByCId(CId);
		  System.out.println(usdetail);
	      return usdetail;
	   }
	  
	  @PutMapping("/user/update/{CId}/{pass}") 
	  public ResponseEntity<Userdetails> updateUserExist(@PathVariable("CId")int CId,@PathVariable("pass") String pass) 
	  {
		  Userdetails detail=usRepo.findByCId(CId);
		  detail.setPassword(pass);
		  usRepo.save(detail);
	      return ResponseEntity.ok(detail);
	   }
	  @SuppressWarnings("unchecked")
	@GetMapping("/user/Register/{phone}") 
	  public ResponseEntity<Userdetails> getUserExist2(@PathVariable("phone")BigInteger Phone) {
	  Userdetails usdetail=usRepo.findByPh(Phone);
	  System.out.println(usdetail);
	  if(usdetail==null)
	  {
		  return ResponseEntity.ok(null);
	  }
	  return (ResponseEntity<Userdetails>) ResponseEntity.internalServerError();
	  
	   }
	  @GetMapping("/user/{phone}/{password}")
		public ResponseEntity<?> getUser(@PathVariable("phone") BigInteger phone, @PathVariable String password)
		{
			System.out.println(phone+" "+password);
			Userdetails udetail = usRepo.findByPh(phone);
			System.out.println(udetail);
			
			
			  if(password.equals(udetail.getPassword())) 
			  {
				  return ResponseEntity.ok(udetail);
			  }
			  else
			  {
			  return (ResponseEntity<?>) ResponseEntity.internalServerError();
			  }
			 
		}
	 

	@PutMapping(path = "/user/transaction/{acc1}/{acc2}/{amt}")
	@Transactional
	public ResponseEntity<?> transaction(@PathVariable("acc1") BigInteger accnum1,@PathVariable("acc2") BigInteger accnum2,@PathVariable("amt")double amt) {
		Accountdetails detail1= accRepo.getByAccnum(accnum1);
		Accountdetails detail2= accRepo.getByAccnum(accnum2);
		double Acc1Bal=detail1.getBalance();
		double Acc2Bal=detail2.getBalance();
		if(Acc1Bal-amt<0)
		{
			return (ResponseEntity<?>)ResponseEntity.internalServerError();
		}
		detail1.setBalance(Acc1Bal-amt);
		detail2.setBalance(Acc2Bal+amt);
		accRepo.save(detail1);
		accRepo.save(detail2);
		return ResponseEntity.ok(detail1);
		
	}
	@GetMapping("/user/transaction/{acc1}")
	public ResponseEntity<?> CheckAccnum(@PathVariable("acc1") BigInteger accnum1) {
		Accountdetails detail1= accRepo.getByAccnum(accnum1);

		if(detail1!=null)
			return ResponseEntity.ok(null);
		else
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}


}
