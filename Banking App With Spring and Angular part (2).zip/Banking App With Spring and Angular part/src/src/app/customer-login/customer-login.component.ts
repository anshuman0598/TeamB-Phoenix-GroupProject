import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Userdata } from '../Class/userdata';
import { UserautheticationService } from '../Services/userauthetication.service';
import { UserloginService } from '../Services/userlogin.service';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {
  userdata:Userdata=new Userdata();
  constructor(private usService:UserautheticationService,private route:Router) { }

  ngOnInit(): void {
  }
  custlogin()
  {
    this.usService.authenticate(this.userdata.phone,this.userdata.password);
  }
}
