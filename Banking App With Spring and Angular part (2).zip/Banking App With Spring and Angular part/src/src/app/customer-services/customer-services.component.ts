import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountDetailsComponent } from '../Customer/account-details/account-details.component';

@Component({
  selector: 'app-customer-services',
  templateUrl: './customer-services.component.html',
  styleUrls: ['./customer-services.component.css']
})
export class CustomerServicesComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router) { }

 id:any;
  ngOnInit(): void {
    
  }
  getDetails()
  {
    this.id=this.route.snapshot.params['uid'];
    this.router.navigate(['accountdetails',this.id])

  }
  transfer()
  {
    this.id=this.route.snapshot.params['uid'];
    this.router.navigate(['fundtransfer',this.id])
  }
  checkbal()
  {
    this.id=this.route.snapshot.params['uid'];
    this.router.navigate(['checkbalance',this.id])
  }
  changepassword()
  {
    this.id=this.route.snapshot.params['uid']
    this.router.navigate(['changepassword',this.id])
  }

}
