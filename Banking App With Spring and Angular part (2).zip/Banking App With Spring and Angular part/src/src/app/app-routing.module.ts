import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdmincreateaccountComponent } from './admincreateaccount/admincreateaccount.component';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import { AdminlogoutComponent } from './adminlogout/adminlogout.component';
import { AdminupdateuserComponent } from './adminupdateuser/adminupdateuser.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerServicesComponent } from './customer-services/customer-services.component';
import { CustomerWelcomeComponent } from './customer-welcome/customer-welcome.component';
import { AccountDetailsComponent } from './Customer/account-details/account-details.component';
import { ChangePasswordComponent } from './Customer/change-password/change-password.component';
import { CheckBalanceComponent } from './Customer/check-balance/check-balance.component';
import { FundTransferComponent } from './Customer/fund-transfer/fund-transfer.component';
import { RouteGuardServicesService } from './Services/route-guard-services.service';
import { UserRouteGuardService } from './Services/user-route-guard.service';
import { OnuseracccreateComponent } from './Successful/onuseracccreate/onuseracccreate.component';
import { TransactionsuccessComponent } from './Successful/transactionsuccess/transactionsuccess.component';
import { UserLogoutComponent } from './user-logout/user-logout.component';
import { UseraccountdetailsComponent } from './useraccountdetails/useraccountdetails.component';
import { UsercreateaccountComponent } from './usercreateaccount/usercreateaccount.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  {path:"",component:WelcomeComponent},
  {path:"welcome",component:WelcomeComponent},
  {path:"admin",component:AdminLoginComponent},
  {path:"admin/admins",component:AdmindetailsComponent,canActivate:[RouteGuardServicesService]},
  {path:"logout",component:AdminlogoutComponent,canActivate:[RouteGuardServicesService]},
  {path:"userdetails",component:UseraccountdetailsComponent,canActivate:[RouteGuardServicesService]},
  {path:"update/:id",component:AdminupdateuserComponent,canActivate:[RouteGuardServicesService]},
  {path:"admin/createacc",component:AdmincreateaccountComponent,canActivate:[RouteGuardServicesService]},
  {path:"onuseracccreate/:condition",component:OnuseracccreateComponent},
  {path:"userAccountCreate",component:UsercreateaccountComponent},
  {path:"userwelcome",component:CustomerWelcomeComponent},
  {path:"customerlogin",component:CustomerLoginComponent},
  {path:"customerlogout",component:UserLogoutComponent,canActivate:[UserRouteGuardService]},
  {path:"bankservice/:uid",component:CustomerServicesComponent,canActivate:[UserRouteGuardService]},
  {path:"accountdetails/:cid",component:AccountDetailsComponent,canActivate:[UserRouteGuardService]},
  {path:"fundtransfer/:cid",component:FundTransferComponent,canActivate:[UserRouteGuardService]},
  {path:"checkbalance/:cid",component:CheckBalanceComponent,canActivate:[UserRouteGuardService]},
  {path:"transactionsuccess/:uid",component:TransactionsuccessComponent,canActivate:[UserRouteGuardService]},
  {path:"changepassword/:cid",component:ChangePasswordComponent,canActivate:[UserRouteGuardService]},
  {path:"**",component:WelcomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
