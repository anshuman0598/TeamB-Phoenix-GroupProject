import { Component, OnInit } from '@angular/core';
import { AuthenticationServiceService } from '../Services/authentication-service.service';
import { UserautheticationService } from '../Services/userauthetication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(public adservice:AuthenticationServiceService,public usservice:UserautheticationService) { }

  ngOnInit(): void {
    
  }

}
