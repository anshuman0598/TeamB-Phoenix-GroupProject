import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Accountdetails } from '../Class/accountdetails';
import { AdminLoginServiceService } from '../Services/admin-login-service.service';

@Component({
  selector: 'app-adminupdateuser',
  templateUrl: './adminupdateuser.component.html',
  styleUrls: ['./adminupdateuser.component.css']
})
export class AdminupdateuserComponent implements OnInit {
  accdetail:Accountdetails=new Accountdetails();
  constructor(private accService:AdminLoginServiceService,private route:ActivatedRoute,private router:Router) { }
  id:any
  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
    this.accService.getAccountById(this.id).subscribe(data=>{
      this.accdetail=data;
      console.log(this.accdetail);
    },error=>console.log(error));
  }
  goToAccount(){
    this.router.navigate(['userdetails']);
  }
  onSubmit(){
    this.accService.updateAccount(this.id,this.accdetail).subscribe(data=>{
      this.goToAccount();
    },error=>console.log("error"));
  }

}
