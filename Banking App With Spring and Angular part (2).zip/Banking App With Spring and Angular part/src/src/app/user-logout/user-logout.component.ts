import { Component, OnInit } from '@angular/core';
import { UserautheticationService } from '../Services/userauthetication.service';

@Component({
  selector: 'app-user-logout',
  templateUrl: './user-logout.component.html',
  styleUrls: ['./user-logout.component.css']
})
export class UserLogoutComponent implements OnInit {

  constructor(private usservice:UserautheticationService) { }

  ngOnInit(): void {
    this.usservice.logout();
  }

}
