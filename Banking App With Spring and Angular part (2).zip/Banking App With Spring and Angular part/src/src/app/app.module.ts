import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { FormsModule } from '@angular/forms';
import { WelcomeComponent } from './welcome/welcome.component';
import { HeaderComponent } from './header/header.component';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import { AdminlogoutComponent } from './adminlogout/adminlogout.component';
import { UseraccountdetailsComponent } from './useraccountdetails/useraccountdetails.component';
import { AdminupdateuserComponent } from './adminupdateuser/adminupdateuser.component';
import { AdmincreateaccountComponent } from './admincreateaccount/admincreateaccount.component';
import { UsercreateaccountComponent } from './usercreateaccount/usercreateaccount.component';
import { OnuseracccreateComponent } from './Successful/onuseracccreate/onuseracccreate.component';
import { CustomerWelcomeComponent } from './customer-welcome/customer-welcome.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerServicesComponent } from './customer-services/customer-services.component';
import { AccountDetailsComponent } from './Customer/account-details/account-details.component';
import { FundTransferComponent } from './Customer/fund-transfer/fund-transfer.component';
import { TransactionsuccessComponent } from './Successful/transactionsuccess/transactionsuccess.component';
import { UserLogoutComponent } from './user-logout/user-logout.component';
import { CheckBalanceComponent } from './Customer/check-balance/check-balance.component';
import { ChangePasswordComponent } from './Customer/change-password/change-password.component';
@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    WelcomeComponent,
    HeaderComponent,
    AdmindetailsComponent,
    AdminlogoutComponent,
    UseraccountdetailsComponent,
    AdminupdateuserComponent,
    AdmincreateaccountComponent,
    UsercreateaccountComponent,
    OnuseracccreateComponent,
    CustomerWelcomeComponent,
    CustomerLoginComponent,
    CustomerServicesComponent,
    AccountDetailsComponent,
    FundTransferComponent,
    TransactionsuccessComponent,
    UserLogoutComponent,
    CheckBalanceComponent,
    ChangePasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
