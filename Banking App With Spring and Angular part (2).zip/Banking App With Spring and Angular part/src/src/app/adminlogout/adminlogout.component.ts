import { Component, OnInit } from '@angular/core';
import { AuthenticationServiceService } from '../Services/authentication-service.service';

@Component({
  selector: 'app-adminlogout',
  templateUrl: './adminlogout.component.html',
  styleUrls: ['./adminlogout.component.css']
})
export class AdminlogoutComponent implements OnInit {

  constructor(private adservice:AuthenticationServiceService) { }

  ngOnInit(): void {
      this.adservice.logout();
  }

}
