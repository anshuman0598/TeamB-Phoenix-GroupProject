import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Accountdetails } from 'src/app/Class/accountdetails';
import { Userdata } from 'src/app/Class/userdata';
import { UserloginService } from 'src/app/Services/userlogin.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  constructor(private route:ActivatedRoute,private usService:UserloginService,private router:Router) { }
  id:any;
  accountnum:BigInt|any;
  amt:number| any;
  condition=false;
  account1:Accountdetails|any
  account2:Accountdetails|any;
  user:Userdata|any;
  mpin:number|any;
  mympin:number|any;
  ngOnInit(): void {
    this.id=this.route.snapshot.params['cid'];
    this.usService.retrieveUserDetail(this.id).subscribe(data =>
      {
          this.account1=data
          console.log(this.account1.accnumber)
         // console.log(this.account2.CustomerId);

      }
    );
    this.usService.findUser(this.id).subscribe(data=>{
      this.user=data;
      console.log(this.user.mpin)
    });
  }
  transfer()
  {
    this.usService.transaction(this.account1.accnumber,this.accountnum,this.amt,this.account1).subscribe
    (data=>{
        this.account2=data;
        this.router.navigate(['transactionsuccess',this.id]);
        
    },error=>alert("Sorry you have Insufficient Balance"));
  }
  getDetails()
  {
    console.log(this.accountnum,this.amt)
    if(this.user.mpin!=this.mpin)
        {
            alert("Your Mpin Is Invalid")
        }
        else{
          this.usService.retrieveUserByAccnum(this.accountnum).subscribe(data =>
            {
                this.transfer();
            },error=>{alert("Invalid Account Number")});
        }
    
      

  }
  goback()
  {
    this.router.navigate(['bankservice',this.id])
  }


}
