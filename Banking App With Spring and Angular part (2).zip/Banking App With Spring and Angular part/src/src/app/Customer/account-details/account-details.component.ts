import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Accountdetails } from 'src/app/Class/accountdetails';
import { UserloginService } from 'src/app/Services/userlogin.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  accounts:Accountdetails=new Accountdetails();
  id:any;
  constructor(private route:ActivatedRoute,private usService:UserloginService,private router:Router) { }

  ngOnInit(): void {
    this.getDetails()
  }
  getDetails()
  {
    this.id=this.route.snapshot.params['cid'];
    console.log(this.id)
    this.usService.retrieveUserDetail(this.id).subscribe(data =>
      {
        
          this.accounts=data
          console.log(this.accounts.CustomerId);
      }
    )

  }
  goback()
  {
    this.router.navigate(['bankservice',this.id])
  }

}
