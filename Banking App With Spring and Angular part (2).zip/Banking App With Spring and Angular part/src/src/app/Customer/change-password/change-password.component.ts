import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Userdata } from 'src/app/Class/userdata';
import { UserloginService } from 'src/app/Services/userlogin.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  constructor(private route:ActivatedRoute,private router:Router,private usservice:UserloginService){}
  npassword:any;
  opassword:any;
  userdata:Userdata|any;
  id:any;
  ngOnInit(): void {
    this.id=this.route.snapshot.params['cid'];
    this.usservice.findUser(this.id).subscribe(data=>{
      this.userdata=data;
    })

  }
  changepass()
  {
    if(this.userdata.password!=this.opassword)
    {
      alert("Your Old Password is Wrong !!!")
    }
    else if(this.userdata.password===this.npassword)
    {
      alert("Your new password and old password can't be same!!!")
    }
    else
    {

    this.usservice.updateUser(this.id,this.npassword,this.userdata).subscribe(data=>{
        alert("Password Updated Successfully, Login Again With New Password")
        this.router.navigate(['customerlogout'])
    }
      );
    }
  }
  goback()
  {
    this.router.navigate(['bankservice',this.id])
  }

}
