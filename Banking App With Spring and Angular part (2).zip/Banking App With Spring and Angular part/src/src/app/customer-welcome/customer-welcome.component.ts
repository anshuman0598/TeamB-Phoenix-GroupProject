import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-welcome',
  templateUrl: './customer-welcome.component.html',
  styleUrls: ['./customer-welcome.component.css']
})
export class CustomerWelcomeComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  userAccountLogin()
  {
    this.router.navigate(['customerlogin'])
  }

  userAccountCreate()
  {
    this.router.navigate(['userAccountCreate'])
  }
  
}
