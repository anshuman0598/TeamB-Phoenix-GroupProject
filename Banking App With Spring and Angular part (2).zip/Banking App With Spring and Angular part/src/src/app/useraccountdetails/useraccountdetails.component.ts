import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Accountdetails } from '../Class/accountdetails';
import { AdminLoginServiceService } from '../Services/admin-login-service.service';

@Component({
  selector: 'app-useraccountdetails',
  templateUrl: './useraccountdetails.component.html',
  styleUrls: ['./useraccountdetails.component.css']
})
export class UseraccountdetailsComponent implements OnInit {
  accounts:Accountdetails|any;
  constructor(private adservice:AdminLoginServiceService,private router: Router) { }

  ngOnInit(): void {
    this.getAccounts();
  }
  getAccounts()
  {
    this.adservice.getAccountList().subscribe(data=>{
      this.accounts=data;
      console.log(this.accounts);
      });
     
  }
  updateAccount(id: any)
  {
    this.router.navigate(['update', id]);
  }
  delete(id:any)
  {
    this.adservice.deleteAccount(id).subscribe(data =>
      {
        alert("Id "+ id +" Deleted Successfully")
        this.getAccounts()
      })
    
  }

}
