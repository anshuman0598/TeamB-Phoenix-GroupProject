import { TestBed } from '@angular/core/testing';

import { RouteGuardServicesService } from './route-guard-services.service';

describe('RouteGuardServicesService', () => {
  let service: RouteGuardServicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RouteGuardServicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
