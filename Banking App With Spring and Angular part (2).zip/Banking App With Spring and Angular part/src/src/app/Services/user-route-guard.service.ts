import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { UserautheticationService } from './userauthetication.service';

@Injectable({
  providedIn: 'root'
})
export class UserRouteGuardService {

  constructor(private userlogin:UserautheticationService,private router:Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean
  {
    if(this.userlogin.isUserLoggedIn())
    {
      return true;
    }
    this.router.navigate(['customerlogin'])
    return false;
  }
}
