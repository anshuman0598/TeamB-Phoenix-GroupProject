import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Userdata } from '../Class/userdata';
import { UserloginService } from './userlogin.service';

@Injectable({
  providedIn: 'root'
})
export class UserautheticationService {
  userdata:Userdata=new Userdata();
  id:any;
  constructor(private usService:UserloginService,private router:Router) { }
  authenticate(phone:any,password:any) 
  {
    //console.log(this.retrieveAdmin(phone,password)+"hiii");
   this.usService.custlogin(phone,password).subscribe(data =>{
       this.userdata=data;
       this.id=data;
       console.log(this.userdata)
      sessionStorage.setItem("AuthenticatedCustomer",data.phone)
      this.router.navigate(['bankservice',this.userdata.cid]);
      
    },error =>{
    //console.log("data not found")
    alert("Invalid Credentials!! Try giving correct Phone Number and Password")
    });
    
  }
  isUserLoggedIn()
  {
    let ad=sessionStorage.getItem("AuthenticatedCustomer");
    return !(ad==null)
  }
  logout()
  {
    sessionStorage.removeItem("AuthenticatedCustomer");
    this.router.navigate(["welcome"])
  }
}
