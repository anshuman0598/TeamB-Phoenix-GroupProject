import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../Class/admin';
import { AdminLoginServiceService } from './admin-login-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService {

  admin:Admin|any
  
  constructor(private adservice:AdminLoginServiceService,private router:Router) { }
  authenticate(phone:any,password:any) 
  {
    //console.log(this.retrieveAdmin(phone,password)+"hiii");
   this.adservice.retrieveAdmin(phone,password).subscribe(data =>{
       this.admin=data;
      console.log(this.admin)
      sessionStorage.setItem("AuthenticatedAdmin",data.aname)
      this.router.navigate(['admin/admins']);
    },error =>{
    //console.log("data not found")
    alert("Invalid Credentials!! Try giving correct Phone Number and Password")
    });
  }
  isAdminLoggedIn()
  {
    let ad=sessionStorage.getItem("AuthenticatedAdmin");
    return !(ad==null)
  }
  logout()
  {
    sessionStorage.removeItem("AuthenticatedAdmin");
    this.router.navigate(["welcome"])
  }
}
