import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Accountdetails } from '../Class/accountdetails';
import { Admin } from '../Class/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminLoginServiceService {
  
  constructor(private httpClient:HttpClient) { }


 
  retrieveAdmin(phone:any, password:any): Observable<Admin>
  {
    return this.httpClient.get<Admin>(`http://localhost:8081/admin/${phone}/${password}`)
  }
  getadminList(): Observable<Admin[]>
  {
    return this.httpClient.get<Admin[]>(`http://localhost:8081/admin/admins`)
  }
  getAccountList(): Observable<Accountdetails[]>
  {
    return this.httpClient.get<Accountdetails[]>(`http://localhost:8081/admin/useraccountdetails/`)
  }
  getAccountById(id : any): Observable<Accountdetails>
  {
    return this.httpClient.get<Accountdetails>(`http://localhost:8081/admin/useraccountdetail/${id}`)
  }
  updateAccount(id:any,accdetail:Accountdetails)
  {
    return this.httpClient.put(`http://localhost:8081/admin/bankusers/update/${id}`,accdetail)
  }
  deleteAccount(id:any)
  {
    return this.httpClient.delete(`http://localhost:8081/admin/userdetail/delete/${id}`)
  }
  createAccount(accdetail:Accountdetails)
  {
    return this.httpClient.post(`http://localhost:8081/admin/bankusers/create`,accdetail)
  }
}
