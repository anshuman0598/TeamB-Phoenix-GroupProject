import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Accountdetails } from '../Class/accountdetails';
import { Userdata } from '../Class/userdata';
import { AccountDetailsComponent } from '../Customer/account-details/account-details.component';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserloginService {
  

  constructor(private httpClient:HttpClient) { }
  createuserAccount(usdetail:Userdata)
  {
    return this.httpClient.post(`http://localhost:8081/user/createuser`,usdetail)
  }
  checkUserExistOrNot(phone:any) {
    return this.httpClient.get(`http://localhost:8081/user/Register/${phone}`)
  }
  custlogin(phone:any,password:any):Observable<Userdata>
  {
    return this.httpClient.get<Userdata>(`http://localhost:8081/user/${phone}/${password}`)
  }
  retrieveUserDetail(id:any) : Observable<Accountdetails>
  {
    return this.httpClient.get<Accountdetails>(`http://localhost:8081/admin/useraccountdetail/${id}`)

  }
  retrieveUserByAccnum(acc2:any):Observable<Accountdetails>
  {
    return this.httpClient.get<Accountdetails>(`http://localhost:8081/user/transaction/${acc2}`)
  }
  transaction(acc1:any,acc2:any,amt:any,accdetail:Accountdetails):Observable<Accountdetails>
  {
    return this.httpClient.put<Accountdetails>(`http://localhost:8081/user/transaction/${acc1}/${acc2}/${amt}`,accdetail)
  }
  findUser(id:any):Observable<Userdata>
  {
    return this.httpClient.get<Userdata>(`http://localhost:8081/user/find/${id}`)
  }
  updateUser(id:any,newpass:any,usdetail:Userdata):Observable<Userdata>
  {
    return this.httpClient.put<Userdata>(`http://localhost:8081/user/update/${id}/${newpass}`,usdetail)
  }
}