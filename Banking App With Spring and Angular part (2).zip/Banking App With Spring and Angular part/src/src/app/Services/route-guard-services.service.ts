import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AdminLoginServiceService } from './admin-login-service.service';
import { AuthenticationServiceService } from './authentication-service.service';


@Injectable({
  providedIn: 'root'
})
export class RouteGuardServicesService implements CanActivate {

  constructor(private adminlogin:AuthenticationServiceService,private router:Router ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean
  {
    if(this.adminlogin.isAdminLoggedIn())
    {
      return true;
    }
    this.router.navigate(['admin']);
    return false;
  }
  
}
