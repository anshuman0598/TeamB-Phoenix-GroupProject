import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsercreateaccountComponent } from './usercreateaccount.component';

describe('UsercreateaccountComponent', () => {
  let component: UsercreateaccountComponent;
  let fixture: ComponentFixture<UsercreateaccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsercreateaccountComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsercreateaccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
