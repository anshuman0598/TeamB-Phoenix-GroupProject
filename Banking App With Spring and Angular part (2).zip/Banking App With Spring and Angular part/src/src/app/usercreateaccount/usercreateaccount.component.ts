import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Accountdetails } from '../Class/accountdetails';
import { Userdata } from '../Class/userdata';
import { AdminLoginServiceService } from '../Services/admin-login-service.service';
import { UserloginService } from '../Services/userlogin.service';

@Component({
  selector: 'app-usercreateaccount',
  templateUrl: './usercreateaccount.component.html',
  styleUrls: ['./usercreateaccount.component.css']
})
export class UsercreateaccountComponent implements OnInit {
   // account: Accountdetails= new Accountdetails();
  constructor(private usService:UserloginService ,private router:Router) {}
  account:Userdata=new Userdata()
  
  ngOnInit(): void {
  }
  saveAccount(){
    console.log(this.account)
    this.usService.createuserAccount(this.account).subscribe(data=>{
      console.log(data);
      this.goToAccount();
    },error=>this.router.navigate(['onuseracccreate',0]));
  }
  goToAccount(){
    this.router.navigate(['onuseracccreate',1]);
  }
  checkIfExixt(phone : any)
  {
    this.usService.checkUserExistOrNot(phone).subscribe(data=>{
      this.saveAccount();
    },error=>this.router.navigate(['onuseracccreate',3]));
    
    
  }
  onSubmit(){
    //console.log(this.account)
    this.checkIfExixt(this.account.phone);
  }
  
  }
  