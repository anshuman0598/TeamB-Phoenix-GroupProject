import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OnuseracccreateComponent } from './onuseracccreate.component';

describe('OnuseracccreateComponent', () => {
  let component: OnuseracccreateComponent;
  let fixture: ComponentFixture<OnuseracccreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OnuseracccreateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OnuseracccreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
