import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-onuseracccreate',
  templateUrl: './onuseracccreate.component.html',
  styleUrls: ['./onuseracccreate.component.css']
})
export class OnuseracccreateComponent implements OnInit {

  constructor(private route: ActivatedRoute) { }
  bankaccexist: any
  ngOnInit(): void {
      this.bankaccexist=this.route.snapshot.params['condition']
      console.log(this.bankaccexist)
  }
  

}
