import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-transactionsuccess',
  templateUrl: './transactionsuccess.component.html',
  styleUrls: ['./transactionsuccess.component.css']
})
export class TransactionsuccessComponent implements OnInit {

  constructor(private router: Router,private route :ActivatedRoute) { }
  id:any;
  ngOnInit(): void {
    this.id=this.route.snapshot.params['uid'];
  }
  back(){
    this.router.navigate(['bankservice',this.id])
  }

}
