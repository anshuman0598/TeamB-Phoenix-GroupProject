import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../Class/admin';
import { AdminLoginServiceService } from '../Services/admin-login-service.service';

@Component({
  selector: 'app-admindetails',
  templateUrl: './admindetails.component.html',
  styleUrls: ['./admindetails.component.css']
})
export class AdmindetailsComponent implements OnInit {

admins:Admin[]|any;
  constructor(private router:Router,private adservice:AdminLoginServiceService) { }

  ngOnInit(): void {
    this.refreshAdmins()
  }
  refreshAdmins()
  {
    
    this.adservice.getadminList().subscribe(data =>{
      console.log(data);
      this.admins=data;
  });
  }
}

