import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AdmindetailsComponent } from '../admindetails/admindetails.component';
import { Admin } from '../Class/admin';
import { AdminLoginServiceService } from '../Services/admin-login-service.service';
import { AuthenticationServiceService } from '../Services/authentication-service.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})

export class AdminLoginComponent implements OnInit {

  admin:Admin = new Admin();
  admindetail : Admin[] |any
  invalidAdmin=false
  constructor(private router:Router, private adservice:AuthenticationServiceService) { }
  ngOnInit(): void {
   
  }
  handleAdmin()
  {
    //this.router.navigate(["welcome"])
    this.adservice.authenticate(this.admin.phone,this.admin.password)

  }
}
