import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Accountdetails } from '../Class/accountdetails';
import { AdminLoginServiceService } from '../Services/admin-login-service.service';
import { UseraccountdetailsComponent } from '../useraccountdetails/useraccountdetails.component';

@Component({
  selector: 'app-admincreateaccount',
  templateUrl: './admincreateaccount.component.html',
  styleUrls: ['./admincreateaccount.component.css']
})
export class AdmincreateaccountComponent implements OnInit 
{
  account: Accountdetails= new Accountdetails();
constructor(private adService:AdminLoginServiceService,private router:Router) {}

ngOnInit(): void {
}
saveAccount(){
  this.adService.createAccount(this.account).subscribe(data=>{
    console.log(data);
    this.goToAccount();
  },error=>console.log(error));
}
goToAccount(){
  this.router.navigate(['userdetails']);
}
onSubmit(){
  console.log(this.account)
  this.saveAccount();
}

}

