export class Admin {
    Adminid:any ;
    aname:string | any;
    phone:BigInt | any;
    email:string | any;
    password:string |any;
}
