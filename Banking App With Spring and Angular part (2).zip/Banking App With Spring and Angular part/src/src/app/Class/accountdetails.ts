export class Accountdetails {
    CustomerId:any;  
    name:String|any;
    dob:Date|any;
    accnumber:bigint|any;
    phone:bigint|any;
    email:string|any;
    balance:number|any;

}
