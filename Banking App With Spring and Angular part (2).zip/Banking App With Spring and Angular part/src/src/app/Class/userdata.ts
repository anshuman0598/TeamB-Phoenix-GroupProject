export class Userdata {
    id:any;
    phone:any;
    password:any;
    cid:any;
    mpin:any;
}
