import { Accountdetails } from './accountdetails';

describe('Accountdetails', () => {
  it('should create an instance', () => {
    expect(new Accountdetails()).toBeTruthy();
  });
});
